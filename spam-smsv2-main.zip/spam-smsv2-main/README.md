# Spam Sms V2
```
Tools ini dibuat untuk nyepam temen, mantan, kang tipu pasti auto minta ampun dah :v
```
> Script ini sewaktu-waktu bisa jadi limit ataupun coid jadi jangan salahin author nya ya goblok.
